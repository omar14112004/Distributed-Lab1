// Package rpc implements a small reflection-based RPC system over TCP.
package rpc

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"reflect"
	"strings"
	"sync"
	"time"
	"unicode"
)

const (
	maxArguments     = 8
	maxArgumentBytes = 1 << 20
	maxRequestBytes  = 4 << 20
	// The wire request also contains the method name and JSON framing, so its
	// size can exceed the combined argument limit while remaining valid.
	maxWireRequestBytes = maxRequestBytes + maxArgumentBytes
	defaultCallTimeout  = 5 * time.Second
)

type request struct {
	Method string            `json:"method"`
	Args   []json.RawMessage `json:"args"`
}

type response struct {
	OK    bool            `json:"ok"`
	Value json.RawMessage `json:"value,omitempty"`
	Error string          `json:"error,omitempty"`
}

// Server exposes exported methods of a receiver over TCP.
type Server struct {
	receiver   any
	listener   net.Listener
	stopped    chan struct{}
	acceptDone chan struct{}
	stopDone   chan struct{}
	workers    sync.WaitGroup
	mu         sync.Mutex
	stopping   bool
}

// NewServer creates a server for a non-nil pointer receiver.
func NewServer(receiver any) (*Server, error) {
	if receiver == nil {
		return nil, errors.New("receiver cannot be nil")
	}
	value := reflect.ValueOf(receiver)
	if value.Kind() != reflect.Pointer || value.IsNil() {
		return nil, errors.New("receiver must be a non-nil pointer")
	}
	return &Server{receiver: receiver}, nil
}

// Start begins accepting remote calls at address. Use port 0 to request an available port.
func (s *Server) Start(address string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.listener != nil || s.stopping {
		return errors.New("server is already running or stopping")
	}
	listener, err := net.Listen("tcp", address)
	if err != nil {
		return err
	}
	s.listener = listener
	s.stopped = make(chan struct{})
	s.acceptDone = make(chan struct{})
	go s.acceptLoop(listener, s.stopped, s.acceptDone)
	return nil
}

// Address returns the active listener's address, including the actual port.
func (s *Server) Address() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.listener == nil || s.stopping {
		return ""
	}
	return s.listener.Addr().String()
}

// Stop stops accepting connections and waits for active handlers to finish.
func (s *Server) Stop() error {
	s.mu.Lock()
	if s.stopping {
		done := s.stopDone
		s.mu.Unlock()
		if done != nil {
			<-done
		}
		return nil
	}
	if s.listener == nil {
		s.mu.Unlock()
		return nil
	}
	s.stopping = true
	s.stopDone = make(chan struct{})
	stopDone := s.stopDone
	listener := s.listener
	stopped := s.stopped
	acceptDone := s.acceptDone
	close(stopped)
	closeErr := listener.Close()
	s.mu.Unlock()

	<-acceptDone
	s.workers.Wait()

	s.mu.Lock()
	s.listener = nil
	s.stopped = nil
	s.acceptDone = nil
	s.stopping = false
	s.stopDone = nil
	close(stopDone)
	s.mu.Unlock()

	if closeErr != nil && !errors.Is(closeErr, net.ErrClosed) {
		return closeErr
	}
	return nil
}

func (s *Server) acceptLoop(listener net.Listener, stopped <-chan struct{}, done chan<- struct{}) {
	defer close(done)
	for {
		conn, err := listener.Accept()
		if err != nil {
			select {
			case <-stopped:
				return
			default:
				return
			}
		}
		s.mu.Lock()
		if s.listener != listener || s.stopping {
			s.mu.Unlock()
			_ = conn.Close()
			return
		}
		s.workers.Add(1)
		s.mu.Unlock()
		go func(connection net.Conn) {
			defer s.workers.Done()
			s.handle(connection)
		}(conn)
	}
}

// handle reads one request, invokes it, and writes one response.
func (s *Server) handle(connection net.Conn) {
	defer connection.Close()
	encoder := json.NewEncoder(connection)
	defer func() {
		if recovered := recover(); recovered != nil {
			writeResponse(connection, encoder, response{Error: fmt.Sprintf("remote method panicked: %v", recovered)})
		}
	}()

	// A client that sends an incomplete JSON document must not occupy a handler forever.
	if err := connection.SetReadDeadline(time.Now().Add(defaultCallTimeout)); err != nil {
		return
	}
	decoder := json.NewDecoder(bufio.NewReader(io.LimitReader(connection, maxWireRequestBytes+1)))
	var req request
	if err := decoder.Decode(&req); err != nil {
		writeResponse(connection, encoder, response{Error: fmt.Sprintf("invalid request: %v", err)})
		return
	}
	if err := validateRequest(req); err != nil {
		writeResponse(connection, encoder, response{Error: err.Error()})
		return
	}
	result, err := s.invoke(req)
	if err != nil {
		writeResponse(connection, encoder, response{Error: err.Error()})
		return
	}
	payload, err := json.Marshal(result)
	if err != nil {
		writeResponse(connection, encoder, response{Error: fmt.Sprintf("encode result: %v", err)})
		return
	}
	writeResponse(connection, encoder, response{OK: true, Value: payload})
}

// writeResponse starts the write timeout when a response is actually ready.
// This prevents a slow method from consuming the entire socket write deadline.
func writeResponse(connection net.Conn, encoder *json.Encoder, resp response) {
	_ = connection.SetWriteDeadline(time.Now().Add(defaultCallTimeout))
	_ = encoder.Encode(resp)
}

// validateRequest checks protocol limits before reflection or application code runs.
func validateRequest(req request) error {
	if req.Method == "" {
		return errors.New("method cannot be empty")
	}
	for _, r := range req.Method {
		if unicode.IsSpace(r) || unicode.IsControl(r) {
			return errors.New("method name cannot contain whitespace or control characters")
		}
	}
	if len(req.Args) > maxArguments {
		return fmt.Errorf("too many arguments: maximum is %d", maxArguments)
	}
	total := 0
	for i, arg := range req.Args {
		if len(arg) > maxArgumentBytes {
			return fmt.Errorf("argument %d is larger than %d bytes", i, maxArgumentBytes)
		}
		total += len(arg)
		if total > maxRequestBytes {
			return fmt.Errorf("combined arguments are larger than %d bytes", maxRequestBytes)
		}
	}
	return nil
}

// invoke finds a method, converts JSON arguments to its parameter types, and calls it.
func (s *Server) invoke(req request) (any, error) {
	method := reflect.ValueOf(s.receiver).MethodByName(req.Method)
	if !method.IsValid() {
		return nil, fmt.Errorf("unknown method %q", req.Method)
	}
	typeOfMethod := method.Type()
	if typeOfMethod.NumIn() != len(req.Args) {
		return nil, fmt.Errorf("method %q expects %d arguments, got %d", req.Method, typeOfMethod.NumIn(), len(req.Args))
	}
	arguments := make([]reflect.Value, len(req.Args))
	for index, raw := range req.Args {
		argument := reflect.New(typeOfMethod.In(index))
		if err := json.Unmarshal(raw, argument.Interface()); err != nil {
			return nil, fmt.Errorf("argument %d: %v", index, err)
		}
		arguments[index] = argument.Elem()
	}
	outputs, err := callMethodSafely(method, arguments)
	if err != nil {
		return nil, err
	}
	if len(outputs) == 0 {
		return nil, nil
	}
	if last := outputs[len(outputs)-1]; last.Type().Implements(reflect.TypeOf((*error)(nil)).Elem()) {
		if !isNilValue(last) {
			return nil, last.Interface().(error)
		}
		outputs = outputs[:len(outputs)-1]
	}
	if len(outputs) == 0 {
		return nil, nil
	}
	return outputs[0].Interface(), nil
}

func isNilValue(value reflect.Value) bool {
	switch value.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return value.IsNil()
	default:
		return false
	}
}

func callMethodSafely(method reflect.Value, arguments []reflect.Value) (outputs []reflect.Value, err error) {
	defer func() {
		if recovered := recover(); recovered != nil {
			err = fmt.Errorf("remote method panicked: %v", recovered)
		}
	}()
	return method.Call(arguments), nil
}

// Client calls methods on a remote Server.
type Client struct {
	Address string
	Timeout time.Duration
}

// NewClient creates a client for a server address.
func NewClient(address string) (*Client, error) {
	if address == "" {
		return nil, errors.New("address cannot be empty")
	}
	return &Client{Address: address, Timeout: defaultCallTimeout}, nil
}

// Call invokes method and decodes its result into out. Pass nil for no result.
func (c *Client) Call(method string, out any, args ...any) error {
	if strings.TrimSpace(method) == "" {
		return errors.New("method cannot be empty")
	}
	if c == nil || c.Address == "" {
		return errors.New("client address cannot be empty")
	}
	timeout := c.Timeout
	if timeout <= 0 {
		timeout = defaultCallTimeout
	}

	req := request{Method: method, Args: make([]json.RawMessage, len(args))}
	for i, arg := range args {
		encoded, err := json.Marshal(arg)
		if err != nil {
			return fmt.Errorf("encode argument %d: %w", i, err)
		}
		req.Args[i] = encoded
	}
	if err := validateRequest(req); err != nil {
		return err
	}

	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	connection, err := (&net.Dialer{}).DialContext(ctx, "tcp", c.Address)
	if err != nil {
		return fmt.Errorf("connect to RPC server: %w", err)
	}
	defer connection.Close()
	if err := connection.SetDeadline(time.Now().Add(timeout)); err != nil {
		return fmt.Errorf("set RPC deadline: %w", err)
	}
	if err := json.NewEncoder(connection).Encode(req); err != nil {
		return fmt.Errorf("encode request: %w", err)
	}
	var resp response
	if err := json.NewDecoder(connection).Decode(&resp); err != nil {
		return fmt.Errorf("decode response: %w", err)
	}
	if !resp.OK {
		if resp.Error == "" {
			return errors.New("remote call failed")
		}
		return errors.New(resp.Error)
	}
	if out == nil {
		return nil
	}
	if len(resp.Value) == 0 {
		return nil
	}
	if err := json.Unmarshal(resp.Value, out); err != nil {
		return fmt.Errorf("decode result: %w", err)
	}
	return nil
}
