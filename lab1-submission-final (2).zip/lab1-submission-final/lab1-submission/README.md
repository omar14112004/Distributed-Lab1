# Lab 1 — RPC

## Run the tests

From this directory (the directory containing `go.mod`), run:

```sh
go test ./...
go vet ./...
```

The race detector requires a working C compiler/CGO setup on Windows:

```sh
go test -race ./...
```

## Run the sample

```sh
go run ./cmd/ping
```
